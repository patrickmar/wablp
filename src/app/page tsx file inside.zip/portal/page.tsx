"use client";

import { useState } from "react";
import { AnalyticsPage } from "@/components/portal/AnalyticsPage";
import { DashboardPage } from "@/components/portal/DashboardPage";
import { MessagesPage } from "@/components/portal/MessagesPage";
import { OpportunitiesPage } from "@/components/portal/OpportunitiesPage";
import { PortalLayout } from "@/components/portal/PortalLayout";
import { ProfilePage } from "@/components/portal/ProfilePage";
import { NewsEventsPage } from "@/components/portal/NewsEventsPage";
import { CommunityMembersPage } from "@/components/portal/CommunityMembersPage";
import { JobsPage } from "@/components/portal/JobsPage";
import { TrainingPage } from "@/components/portal/TrainingPage";
import { DealsPage } from "@/components/portal/DealsPage";
import { MembersCataloguePage } from "@/components/portal/MembersCataloguePage";
import { ServicesDirectoryPage } from "@/components/portal/ServicesDirectoryPage";
import { OrdersPage } from "@/components/portal/OrdersPage";

const Members = () => {
  const [page, setPage] = useState("dashboard"); // default page

  return (
    <PortalLayout currentPage={page} onPageChange={setPage}>
      {page === "dashboard" && <DashboardPage />}
      {page === "dashboard" && <NewsEventsPage />}
      {page === "profile" && <ProfilePage />}
      {page === "profile" && <CommunityMembersPage />}
      {page === "profile" && <JobsPage />}
      {page === "profile" && <TrainingPage />}
      {page === "profile" && <DealsPage />}
      {page === "profile" && <MembersCataloguePage />}
      {page === "profile" && <ServicesDirectoryPage />}
      {page === "profile" && <OrdersPage />}
      {/* {page === "messages" && <MessagesPage />}
      {page === "opportunities" && <OpportunitiesPage />}
      {page === "analytics" && <AnalyticsPage />} */}
      
    </PortalLayout>
  );
};

export default Members;


// const Members = () => {
//   return (
//     <>
//       <AnalyticsPage />
//             <DashboardPage />
//             <MessagesPage />
//             <OpportunitiesPage />
//             <PortalLayout children={undefined} currentPage={""} onPageChange={function (page: string): void {
//               throw new Error("Function not implemented.");
//           } } />
//             <ProfilePage />
//     </>
//   );
// };

// export default Members;