const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");

const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");
const statsRoutes = require("./routes/stats");
const newsRoutes = require("./routes/news");
const newsfullRoutes = require("./routes/newsfull");
const customersRoutes = require("./routes/customers");

const app = express();

app.use(cors());
app.use(bodyParser.json());

// Path to your XAMPP uploads folder
const EXTERNAL_UPLOADS = "C:/xampp/htdocs/Wablp/admin/";

// Serve real uploaded photos (only if the folder exists)
if (fs.existsSync(EXTERNAL_UPLOADS)) {
  console.log("✅ Serving images from:", EXTERNAL_UPLOADS);
  app.use("/posts_photos", express.static(EXTERNAL_UPLOADS));
} else {
  console.error("❌ Folder not found:", EXTERNAL_UPLOADS);
}

// Fallback (default.jpg, etc.) inside your Node project
app.use("/uploads", express.static(path.join(__dirname, "public/uploads")));

/** ---- ROUTES ---- **/
app.use("/api/auth", authRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/routes", statsRoutes);
app.use("/routes/news", newsRoutes);
app.use("/routes/newsfull", newsfullRoutes);
app.use("/routes/customers", customersRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));









// const express = require("express");
// const cors = require("cors");
// const bodyParser = require("body-parser");
// const path = require("path");

// const authRoutes = require("./routes/auth");
// const dashboardRoutes = require("./routes/dashboard");
// const statsRoutes = require("./routes/stats");
// const newsRoutes = require("./routes/news");

// const app = express();

// app.use(cors());
// app.use(bodyParser.json());

// // Serve actual uploaded photos from XAMPP folder
// app.use(
//   "/uploads",
//   express.static("C:/xampp/htdocs/Wablp/admin/posts_photos")
// );

// // Serve fallback default.jpg from your Node project (backend/public/uploads)
// app.use(
//   "/uploads",
//   express.static(path.join(__dirname, "public/uploads"))
// );

// // Routes
// app.use("/api/auth", authRoutes);
// app.use("/api/dashboard", dashboardRoutes);
// app.use("/routes", statsRoutes); // Updated to match frontend fetch
// app.use("/routes/news", newsRoutes);

// const PORT = 5000;
// app.listen(PORT, () =>
//   console.log(`🚀 Server running at http://localhost:${PORT}`)
// );
