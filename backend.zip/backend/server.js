const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");

const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");
const statsRoutes = require("./routes/stats");
const newsRoutes = require("./routes/news");

const app = express();

app.use(cors());
app.use(bodyParser.json());

// Serve actual uploaded photos from XAMPP folder
app.use(
  "/uploads",
  express.static("C:/xampp/htdocs/Wablp/admin/posts_photos")
);

// Serve fallback default.jpg from your Node project (backend/public/uploads)
app.use(
  "/uploads",
  express.static(path.join(__dirname, "public/uploads"))
);

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/routes", statsRoutes); // Updated to match frontend fetch
app.use("/routes/news", newsRoutes);

const PORT = 5000;
app.listen(PORT, () =>
  console.log(`🚀 Server running at http://localhost:${PORT}`)
);
